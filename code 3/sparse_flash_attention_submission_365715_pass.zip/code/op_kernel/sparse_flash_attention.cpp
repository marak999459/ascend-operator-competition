// Kernel侧核函数实现：SparseFlashAttention（分块 + 在线 softmax）
//
// ============================================================
// 语义依据：官方 SFA kernel 源码（见 _sfa/SEMANTICS.md，逐条有出处）
//   - sparseIndices 是【块号】: token 区间 = [blk*SBS, blk*SBS+SBS)
//   - -1 是无效哨兵，【遇到即停止扫描】
//   - 块被 thr 截断: end = min(begin+SBS, thr)
//   - mode3: thr = (act_kv - act_q) + s + 1  ← 等价于官方因果掩码判据
//   - 展开时按 thr 截断即已实现掩码，无需逐元素比较
//   - 全 mask 行 -> 输出全 0, LSE = (-2e38, 0)
//   - 变长: actual_seq_lengths 是 per-batch 值 arr[b]（长度 1 时广播）
//
// 结构（从第一天就是快的）：
//   核间：按 B*Q_S 个 query token 展平均分，核间无重叠 -> 无需任何核间同步
//         ⚠️ 绝不用 SyncAll（上道题的死锁根因）
//   核内：for tok -> for head-block(nb) -> for KV-chunk(n_blk)
//         在线 softmax：只保留 O[nb,D] + m[nb] + l[nb]，与稀疏长度 m 无关
//
// 当前状态：内层为标量，先保证正确性；向量化是下一步（性能阶段）。
// ============================================================
#include "kernel_operator.h"

#include "sparse_flash_attention_tiling.h"
#include "tiling_key_sparse_flash_attention.h"

using namespace AscendC;

namespace sfa {
constexpr float  SOFTMAX_MIN_NUM = -2e38f;   // 官方 SOFTMAX_MIN_NUM
constexpr int32_t HQ_DIM   = 512;            // Q_D / KV_D
constexpr int32_t ROPE_DIM = 64;             // Dr
constexpr int32_t QD_ROPE  = HQ_DIM + ROPE_DIM;   // 576

// 设备侧无 expf（CANN 9.0.0）：范围归约 + 泰勒展开
__aicore__ inline float ExpPoly(float x)
{
    const float LN2 = 0.6931471805599453f;
    const float INV_LN2 = 1.4426950408889634f;
    if (x < -87.0f) { return 0.0f; }
    if (x > 88.0f)  { x = 88.0f; }
    const float xf = x * INV_LN2;
    int32_t k = static_cast<int32_t>(xf);
    if (xf < 0.0f && static_cast<float>(k) != xf) { --k; }   // floor
    const float r = x - static_cast<float>(k) * LN2;
    float p = 1.0f / 120.0f;
    p = p * r + (1.0f / 24.0f);
    p = p * r + (1.0f / 6.0f);
    p = p * r + 0.5f;
    p = p * r + 1.0f;
    p = p * r + 1.0f;
    if (k + 127 <= 0) { return 0.0f; }
    int32_t bits = (k + 127) << 23;
    if (bits >= 0x7F800000) { bits = 0x7F7FFFFF; }
    union { int32_t i; float f; } u;
    u.i = bits;
    return p * u.f;
}


// bf16 <-> float32 软件转换（设备侧）
__aicore__ inline float Bf16ToFloat(uint16_t raw)
{
    union { uint32_t i; float f; } u;
    u.i = (uint32_t)raw << 16;
    return u.f;
}
__aicore__ inline uint16_t FloatToBf16(float val)
{
    union { uint32_t i; float f; } u;
    u.f = val;
    return (uint16_t)(u.i >> 16);
}
}  // namespace sfa

template <typename DT_QUERY>
class KernelSparseFlashAttention {
public:
    __aicore__ inline KernelSparseFlashAttention() {}

    __aicore__ inline void Init(GM_ADDR query, GM_ADDR key, GM_ADDR value,
                                GM_ADDR sparse_indices, GM_ADDR actual_seq_lengths_query,
                                GM_ADDR actual_seq_lengths_kv, GM_ADDR query_rope, GM_ADDR key_rope,
                                GM_ADDR attention_out, GM_ADDR softmax_max_out, GM_ADDR softmax_sum_out,
                                const SparseFlashAttentionTilingData &tiling_data, GM_ADDR trace)
    {
        B_    = tiling_data.B;
        S1_   = tiling_data.Q_S;
        S2_   = tiling_data.KV_S;
        N1_  = tiling_data.Q_N;
        D_   = static_cast<int32_t>(tiling_data.Q_D);
        Dr_  = static_cast<int32_t>(tiling_data.Dr);
        scale_ = tiling_data.scale_value;
        mode_  = tiling_data.sparse_mode;
        sbs_   = tiling_data.sparse_block_size;
        sparseCount_ = tiling_data.sparse_count;
        nb_    = (tiling_data.nb   == 0) ? 1u : tiling_data.nb;
        nBlk_  = (tiling_data.n_blk == 0) ? 1u : tiling_data.n_blk;
        nHeadBlk_ = (N1_ + nb_ - 1) / nb_;
        lseOn_ = (softmax_max_out != nullptr) && (softmax_sum_out != nullptr);
        // ⚠️ 官方 BSND 变长语义：actual_seq_lengths 是【per-batch 值】arr[b]；
        //    数组长度为 1 时广播 arr[0]；未传时用满 padded 的 Q_S / KV_S
        //    （见 SEMANTICS.md §3）。
        //    注意：host 若探测不到数组长度会下发 0；此处对"缓冲存在但长度未知"
        //    按 1（广播）处理 —— 因为回退到 padded 长度会静默算错。
        qLenSize_  = tiling_data.actual_q_len_size;
        kvLenSize_ = tiling_data.actual_kv_len_size;
        isBf16_ = (tiling_data.is_bf16 != 0u);

        if (trace != nullptr) {
            traceGm_.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(trace));
            traceOn_ = true;
            // ⚠️ 真机 ccec 禁止 aicore 函数里 float<->整数 的隐式转换，
            //    所以这里必须显式 static_cast<float>。
            const float bidx = static_cast<float>(GetBlockIdx());
            const float bnum = static_cast<float>(GetBlockNum());
            if ASCEND_IS_AIV {
                TRec(9.0f, bidx, bnum, 1.0f, 0.0f);
            } else {
                TRec(9.0f, bidx, bnum, 0.0f, 0.0f);
            }
        }

        qGm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(query));
        kGm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(key));
        vGm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(value));
        idxGm_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t *>(sparse_indices));
        qrGm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(query_rope));
        krGm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(key_rope));
        outGm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(attention_out));
        qRawGm_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t *>(query));
        kRawGm_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t *>(key));
        vRawGm_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t *>(value));
        qrRawGm_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t *>(query_rope));
        krRawGm_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t *>(key_rope));
        outRawGm_.SetGlobalBuffer(reinterpret_cast<__gm__ uint16_t *>(attention_out));
        if (softmax_max_out != nullptr) { maxGm_.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(softmax_max_out)); }
        if (softmax_sum_out != nullptr) { sumGm_.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(softmax_sum_out)); }
        // 变长长度张量：int32 一维，BSND 下是 per-batch 值
        if (actual_seq_lengths_query != nullptr) {
            qLenGm_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t *>(actual_seq_lengths_query));
            qLenOn_ = true;
            if (qLenSize_ == 0u) { qLenSize_ = 1u; }   // 长度未知 -> 按广播处理
        }
        if (actual_seq_lengths_kv != nullptr) {
            kvLenGm_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t *>(actual_seq_lengths_kv));
            kvLenOn_ = true;
            if (kvLenSize_ == 0u) { kvLenSize_ = 1u; } // 长度未知 -> 按广播处理
        }

        // ---- 核间切分：按 B*Q_S 个 token 展平均分 ----
        // ⚠️ 只有向量核做工（本算子无 Cube 计算）。用 ASCEND_IS_AIV 与官方一致。
        if ASCEND_IS_AIC {
            tokBegin_ = 0; tokEnd_ = 0;
            return;
        }
        const uint32_t total = B_ * S1_;
        const uint32_t coreNum = GetBlockNum();
        const uint32_t coreIdx = GetBlockIdx();
        if (coreNum == 0 || coreIdx >= coreNum) { tokBegin_ = 0; tokEnd_ = 0; return; }
        const uint32_t perCore = (total + coreNum - 1) / coreNum;
        tokBegin_ = coreIdx * perCore;
        tokEnd_ = tokBegin_ + perCore;
        if (tokBegin_ > total) { tokBegin_ = total; }
        if (tokEnd_ > total)   { tokEnd_ = total; }
        if (tokEnd_ < tokBegin_) { tokEnd_ = tokBegin_; }

        // ---- UB 缓冲（大小由 host 的 UB 预算反算保证）----
        pipe_.InitBuffer(qBuf_,  nb_   * (D_ + Dr_) * sizeof(float));
        pipe_.InitBuffer(oBuf_,  nb_   * D_  * sizeof(float));
        pipe_.InitBuffer(kBuf_,  nBlk_ * D_  * sizeof(DT_QUERY));
        pipe_.InitBuffer(vBuf_,  nBlk_ * D_  * sizeof(DT_QUERY));
        pipe_.InitBuffer(krBuf_, nBlk_ * Dr_ * sizeof(DT_QUERY));
        pipe_.InitBuffer(sBuf_,  nb_   * nBlk_ * sizeof(float));
        pipe_.InitBuffer(pBuf_,  nb_   * nBlk_ * sizeof(float));
        pipe_.InitBuffer(mlBuf_, 3 * nb_ * sizeof(float));
        pipe_.InitBuffer(blkBuf_, nBlk_ * sizeof(int32_t));
        pipe_.InitBuffer(lseBuf_, (2 * nb_) * sizeof(float));
    }

    __aicore__ inline void Process()
    {
        for (uint32_t tok = tokBegin_; tok < tokEnd_; ++tok) {
            const uint32_t b = tok / S1_;
            const uint32_t s = tok - b * S1_;
            ProcessToken(b, s);
        }
    }

    // 有效长度：官方 BSND 变长语义 = per-batch 值 arr[b]（见 SEMANTICS.md §3）
    //   size==1 -> 广播 arr[0]；未传 -> 用满 padded 的 Q_S / KV_S
    __aicore__ inline void GetActualLens(uint32_t b, uint32_t &actQ, uint32_t &actKV) const
    {
        actQ = S1_;
        if (qLenOn_ && qLenSize_ > 0) {
            const uint32_t idx = (qLenSize_ == 1) ? 0u : b;
            if (idx < qLenSize_) {
                const int32_t v = qLenGm_.GetValue(idx);
                if (v >= 0 && static_cast<uint32_t>(v) < actQ) {
                    actQ = static_cast<uint32_t>(v);
                }
            }
        }
        actKV = S2_;
        if (kvLenOn_ && kvLenSize_ > 0) {
            const uint32_t idx = (kvLenSize_ == 1) ? 0u : b;
            if (idx < kvLenSize_) {
                const int32_t v = kvLenGm_.GetValue(idx);
                if (v >= 0 && static_cast<uint32_t>(v) < actKV) {
                    actKV = static_cast<uint32_t>(v);
                }
            }
        }
    }

private:
    // ---- traceGm_ 保留为空实现的写入路径（正式提交时 trace == nullptr，编译期即消除）----
    __aicore__ inline void TRec(float tag, float a, float b, float c, float d) const
    {
        if (!traceOn_) { return; }
        GlobalTensor<float> &g = const_cast<GlobalTensor<float> &>(traceGm_);
        uint32_t &o = const_cast<uint32_t &>(traceOff_);
        if (o + 5 > 4096) { return; }
        g.SetValue(o + 0, tag);
        g.SetValue(o + 1, a);
        g.SetValue(o + 2, b);
        g.SetValue(o + 3, c);
        g.SetValue(o + 4, d);
        o += 5;
    }

    __aicore__ inline int64_t CalcThreshold(uint32_t s, uint32_t actQ, uint32_t actKV) const
    {
        if (mode_ == 3) {
            return static_cast<int64_t>(actKV) - static_cast<int64_t>(actQ)
                   + static_cast<int64_t>(s) + 1;
        }
        return static_cast<int64_t>(actKV);
    }

    // 读一个有效稀疏块 -> token 区间 [begin, end)；false 表示扫描结束
    __aicore__ inline bool NextTokenBlock(uint64_t idxBase, uint32_t &tokIdx,
                                          int64_t thr, int64_t &begin, int64_t &end) const
    {
        while (tokIdx < sparseCount_) {
            const int32_t blk = idxGm_.GetValue(idxBase + tokIdx);
            ++tokIdx;
            if (blk < 0) { return false; }                 // 官方：遇 -1 即停
            const int64_t b0 = static_cast<int64_t>(blk) * static_cast<int64_t>(sbs_);
            if (b0 >= thr) { continue; }                    // 官方此处是 continue 而非 break
            int64_t e0 = b0 + static_cast<int64_t>(sbs_);
            if (e0 > thr) { e0 = thr; }                     // 块被 threshold 截断
            begin = b0; end = e0;
            return true;
        }
        return false;
    }

    __aicore__ inline void ProcessToken(uint32_t b, uint32_t s)
    {
        uint32_t actQ = 0, actKV = 0;
        GetActualLens(b, actQ, actKV);

        const uint32_t s1Base   = static_cast<uint32_t>(((static_cast<uint64_t>(b) * S1_ + s) * N1_) * D_);
        const uint32_t ropeBase = static_cast<uint32_t>(((static_cast<uint64_t>(b) * S1_ + s) * N1_) * Dr_);
        const uint64_t idxBase  = (static_cast<uint64_t>(b) * S1_ + s) * sparseCount_;

        // ⚠️ padding query 行（s >= 真实 query 长度）：输出全 0，LSE 取官方哨兵值。
        //    官方参考语义见 SEMANTICS.md 附录 C：`if s >= s1: continue`（输出保持 0）。
        if (s >= actQ) {
            for (uint32_t n = 0; n < N1_; ++n) {
                const uint32_t outOff = s1Base + n * D_;
                for (int32_t d = 0; d < D_; ++d) {
                    outGm_.SetValue(outOff + d, static_cast<DT_QUERY>(0.0f));
                }
            }
            if (lseOn_) {
                // ⚠️ 修复：padding 行 LSE 改为 UB + DataCopyPad 写（与正常分支同机制）。
                //    标量 GM 写在本算子多核并发下偶发整行丢失（VARSBS8 复现 0xAA 残留）。
                LocalTensor<float> lseP = lseBuf_.Get<float>();
                for (uint32_t hb = 0; hb < nHeadBlk_; ++hb) {
                    const uint32_t n0 = hb * nb_;
                    uint32_t nbCur = N1_ - n0;
                    if (nbCur > nb_) { nbCur = nb_; }
                    for (uint32_t i = 0; i < nbCur; ++i) {
                        lseP.SetValue(i, 0.0f);
                        lseP.SetValue(nb_ + i, 0.0f);
                    }
                    const uint32_t lseOff = (static_cast<uint64_t>(b) * S1_ + s) * N1_ + n0;
                    DataCopyPad(maxGm_[lseOff], lseP,     DataCopyExtParams{1, static_cast<uint32_t>(nbCur * sizeof(float)), 0, 0, 0});
                    DataCopyPad(sumGm_[lseOff], lseP[nb_], DataCopyExtParams{1, static_cast<uint32_t>(nbCur * sizeof(float)), 0, 0, 0});
                }
            }
            return;
        }

        const int64_t thr = CalcThreshold(s, actQ, actKV);

        LocalTensor<float> q  = qBuf_.Get<float>();
        LocalTensor<float> o  = oBuf_.Get<float>();
        LocalTensor<DT_QUERY> kb = kBuf_.Get<DT_QUERY>();
        LocalTensor<DT_QUERY> vb = vBuf_.Get<DT_QUERY>();
        LocalTensor<DT_QUERY> kr = krBuf_.Get<DT_QUERY>();
        LocalTensor<float> sc = sBuf_.Get<float>();
        LocalTensor<float> ml = mlBuf_.Get<float>();

        for (uint32_t hb = 0; hb < nHeadBlk_; ++hb) {
            const uint32_t n0 = hb * nb_;
            uint32_t nbCur = N1_ - n0;
            if (nbCur > nb_) { nbCur = nb_; }

            // Q 与 Qrope 拼接：前 512 content，后 64 rope
            for (uint32_t i = 0; i < nbCur; ++i) {
                const uint32_t qOff = s1Base + (n0 + i) * D_;
                const uint32_t rOff = ropeBase + (n0 + i) * Dr_;
                for (int32_t d = 0; d < D_; ++d) {
                    float qv = isBf16_ ? sfa::Bf16ToFloat(qRawGm_.GetValue(qOff + d)) : static_cast<float>(qGm_.GetValue(qOff + d));
                    q.SetValue(i * (D_ + Dr_) + d, qv);
                }
                for (int32_t d = 0; d < Dr_; ++d) {
                    float rv = isBf16_ ? sfa::Bf16ToFloat(qrRawGm_.GetValue(rOff + d)) : static_cast<float>(qrGm_.GetValue(rOff + d));
                    q.SetValue(i * (D_ + Dr_) + D_ + d, rv);
                }


            }
            for (uint32_t i = 0; i < nbCur; ++i) {
                for (int32_t d = 0; d < D_; ++d) { o.SetValue(i * D_ + d, 0.0f); }
                ml.SetValue(i, sfa::SOFTMAX_MIN_NUM);
                ml.SetValue(nb_ + i, 0.0f);
            }

            uint32_t tokIdx = 0;
            int64_t curBegin = 0, curEnd = 0;
            bool hasBlock = false;
            uint32_t filled = 0;

            // ⚠️ 必须支持"一个 sparse block 跨越多个 chunk"（sparseBlockSize 最大 128，
            //    而 UB 只能放下 n_blk 个 token；nBlk_ < sbs_ 时旧写法会越界/错算）。
            //    做法：缓冲区满就 flush，稀疏块的断点（curBegin/curEnd/hasBlock）跨 flush 保留，
            //    由 FlushChunk 的在线 softmax（mOld/mNew 重缩放）保证分段累加等价。
            //    当 nBlk_ >= sbs_ 时（如 SBS=8、nBlk=16）此循环与原逻辑逐位等价。
            while (true) {
                if (!hasBlock) {
                    if (!NextTokenBlock(idxBase, tokIdx, thr, curBegin, curEnd)) { break; }
                    hasBlock = true;
                }
                if (filled == nBlk_) {
                    int64_t kBaseGM = (static_cast<int64_t>(b) * S2_ + (curBegin - filled)) * D_;
                    FlushChunk(q, o, kb, vb, kr, sc, ml, nbCur, filled, kBaseGM);
                    filled = 0;
                }
                const int64_t kOff = (static_cast<int64_t>(b) * S2_ + curBegin) * D_;
                const int64_t rOff = (static_cast<int64_t>(b) * S2_ + curBegin) * Dr_;
                for (int32_t d = 0; d < D_; ++d) {
                    kb.SetValue(filled * D_ + d, kGm_.GetValue(kOff + d));
                    vb.SetValue(filled * D_ + d, vGm_.GetValue(kOff + d));
                }
                for (int32_t d = 0; d < Dr_; ++d) {
                    float rv = isBf16_ ? sfa::Bf16ToFloat(krRawGm_.GetValue(rOff + d)) : static_cast<float>(krGm_.GetValue(rOff + d));
                    kr.SetValue(filled * Dr_ + d, rv);
                }
                ++filled;
                ++curBegin;
                if (curBegin >= curEnd) { hasBlock = false; }
            }
            if (filled > 0) { int64_t kBaseEnd = (static_cast<int64_t>(b) * S2_ + (curBegin - filled)) * D_; FlushChunk(q, o, kb, vb, kr, sc, ml, nbCur, filled, kBaseEnd); }

            // 归一化并写回
        LocalTensor<float> lse = lseBuf_.Get<float>();
            for (uint32_t i = 0; i < nbCur; ++i) {
                const float l = ml.GetValue(nb_ + i);
                const uint32_t outOff = s1Base + (n0 + i) * D_;
                for (int32_t d = 0; d < D_; ++d) {
                    const float val = (l > 0.0f) ? (o.GetValue(i * D_ + d) / l) : 0.0f;
                    o.SetValue(i * D_ + d, val);
                }
                if (lseOn_) {
                    const uint32_t lseOff = (static_cast<uint64_t>(b) * S1_ + s) * N1_ + (n0 + i);
                    // ⚠️ softmaxMax 写【未缩放】的行最大（即 ml 里存的 mx）。
                    //    真机双对拍实测：若在此乘 scale_，max 会恰好偏小 1/scale=22.6274 倍
                    //    （同一用例的 softmax_sum 同时完全正确，证明缩放在 softmax 内部完成、
                    //     不进入 LSE）。此前真机只对拍 attention_out，所以这个错误长期未被发现。
                    lse.SetValue(i,     (l > 0.0f) ? ml.GetValue(i) : 0.0f);
                    lse.SetValue(nb_ + i, (l > 0.0f) ? l : 0.0f);
                }
            }
            if (lseOn_) {
                const uint32_t lseOff = (static_cast<uint64_t>(b) * S1_ + s) * N1_ + n0;
                DataCopyPad(maxGm_[lseOff], lse,     DataCopyExtParams{1, static_cast<uint32_t>(nbCur * sizeof(float)), 0, 0, 0});
                DataCopyPad(sumGm_[lseOff], lse[nb_], DataCopyExtParams{1, static_cast<uint32_t>(nbCur * sizeof(float)), 0, 0, 0});
            }
            for (uint32_t i = 0; i < nbCur; ++i) {
                const uint32_t outOff = s1Base + (n0 + i) * D_;
                for (int32_t d = 0; d < D_; ++d) {
                    float oval = o.GetValue(i * D_ + d); if (isBf16_) { outRawGm_.SetValue(outOff + d, sfa::FloatToBf16(oval)); } else { outGm_.SetValue(outOff + d, static_cast<DT_QUERY>(oval)); }
                }
            }
        }
    }

    /** 处理一个 KV chunk：score -> 在线 softmax 更新 (m, l, O) */
    __aicore__ inline void FlushChunk(LocalTensor<float> &q, LocalTensor<float> &o,
                                      LocalTensor<DT_QUERY> &kb, LocalTensor<DT_QUERY> &vb,
                                      LocalTensor<DT_QUERY> &kr, LocalTensor<float> &sc,
                                      LocalTensor<float> &ml, uint32_t nbCur, uint32_t m, int64_t kBaseGM)
    {
        // 1) score = (q·k + q_rope·k_rope) * scale
        for (uint32_t i = 0; i < nbCur; ++i) {
            const uint32_t qo = i * (D_ + Dr_);
            for (uint32_t j = 0; j < m; ++j) {
                float acc = 0.0f;
                const uint32_t ko = j * D_;
                for (int32_t d = 0; d < D_; ++d) {
                    float kv = isBf16_ ? sfa::Bf16ToFloat(kRawGm_.GetValue(kBaseGM + j * D_ + d)) : static_cast<float>(kb.GetValue(ko + d));
                    acc += q.GetValue(qo + d) * kv;
                }
                const uint32_t ro = j * Dr_;
                for (int32_t d = 0; d < Dr_; ++d) {
                    float krv = isBf16_ ? sfa::Bf16ToFloat(krRawGm_.GetValue(kBaseGM + j * Dr_ + d)) : static_cast<float>(kr.GetValue(ro + d));
                    acc += q.GetValue(qo + D_ + d) * krv;
                }
                sc.SetValue(i * nBlk_ + j, acc * scale_);
            }
        }
        // 2) 行最大 -> mNew
        for (uint32_t i = 0; i < nbCur; ++i) {
            float mx = sc.GetValue(i * nBlk_);
            for (uint32_t j = 1; j < m; ++j) {
                const float v = sc.GetValue(i * nBlk_ + j);
                if (v > mx) { mx = v; }
            }
            const float mOld = ml.GetValue(i);
            ml.SetValue(2 * nb_ + i, (mx > mOld) ? mx : mOld);
        }
        // 3) O = O*exp(mOld-mNew) + exp(S-mNew)·V ;  l = l*exp(mOld-mNew) + Σexp(S-mNew)
        for (uint32_t i = 0; i < nbCur; ++i) {
            const float mOld = ml.GetValue(i);
            const float mNew = ml.GetValue(2 * nb_ + i);
            const float alpha = sfa::ExpPoly(mOld - mNew);
            const uint32_t oo = i * D_;
            for (int32_t d = 0; d < D_; ++d) {
                o.SetValue(oo + d, o.GetValue(oo + d) * alpha);
            }
            float lNew = ml.GetValue(nb_ + i) * alpha;
            for (uint32_t j = 0; j < m; ++j) {
                const float e = sfa::ExpPoly(sc.GetValue(i * nBlk_ + j) - mNew);
                lNew += e;
                const uint32_t vo = j * D_;
                for (int32_t d = 0; d < D_; ++d) {
                    float vv = isBf16_ ? sfa::Bf16ToFloat(vRawGm_.GetValue(kBaseGM + j * D_ + d)) : static_cast<float>(vb.GetValue(vo + d));
                    o.SetValue(oo + d, o.GetValue(oo + d) + e * vv);
                }
            }
            ml.SetValue(i, mNew);
            ml.SetValue(nb_ + i, lNew);
        }
    }

    TPipe pipe_;
    TBuf<TPosition::VECCALC> qBuf_, oBuf_, kBuf_, vBuf_, krBuf_, sBuf_, pBuf_, mlBuf_, blkBuf_, lseBuf_;
    GlobalTensor<DT_QUERY> qGm_, kGm_, vGm_, qrGm_, krGm_, outGm_;
    GlobalTensor<uint16_t> qRawGm_, kRawGm_, vRawGm_, qrRawGm_, krRawGm_, outRawGm_;
    GlobalTensor<int32_t> idxGm_;
    GlobalTensor<int32_t> qLenGm_, kvLenGm_;
    GlobalTensor<float> maxGm_, sumGm_, traceGm_;

    uint32_t B_ = 0, S1_ = 0, S2_ = 0, N1_ = 0;
    int32_t D_ = 512, Dr_ = 64;   // 从 tiling 取，默认 512/64
    uint32_t sbs_ = 1, sparseCount_ = 2048, nb_ = 1, nBlk_ = 1, nHeadBlk_ = 1;
    float scale_ = 1.0f;
    uint32_t mode_ = 3;
    bool lseOn_ = false;
    bool qLenOn_ = false, kvLenOn_ = false;
    uint32_t qLenSize_ = 0, kvLenSize_ = 0;
    bool isBf16_ = false;
    bool traceOn_ = false;
    uint32_t traceOff_ = 0;
    uint32_t tokBegin_ = 0, tokEnd_ = 0;
};

// kernel 入口：与原骨架写法一致 —— 【模板 + __global__ __aicore__，不要 extern "C"】
// ⚠️ 踩坑记录：加 extern "C" 会把它变成非模板函数，导致编译器生成的
//    `sparse_flash_attention<TEMPLATE_PARAMS>(...)` 报
//    "'..._tilingkey' does not name a template but is followed by template arguments"
template <typename DT_QUERY>
__global__ __aicore__ void sparse_flash_attention(
    GM_ADDR query, GM_ADDR key, GM_ADDR value, GM_ADDR sparseIndices,
    GM_ADDR actualSeqLengthsQuery, GM_ADDR actualSeqLengthsKV,
    GM_ADDR queryRope, GM_ADDR keyRope, GM_ADDR attentionOut,
    GM_ADDR softmaxMaxOut, GM_ADDR softmaxSumOut, GM_ADDR workspace, GM_ADDR tiling)
{
    REGISTER_TILING_DEFAULT(SparseFlashAttentionTilingData);
    GET_TILING_DATA_WITH_STRUCT(SparseFlashAttentionTilingData, tiling_data, tiling);
    KernelSparseFlashAttention<DT_QUERY> op;
    op.Init(query, key, value, sparseIndices, actualSeqLengthsQuery, actualSeqLengthsKV,
            queryRope, keyRope, attentionOut, softmaxMaxOut, softmaxSumOut,
            tiling_data, nullptr);
    op.Process();
}

template __aicore__ void sparse_flash_attention<half>(
    GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR,
    GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
template __aicore__ void sparse_flash_attention<float>(
    GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR,
    GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
