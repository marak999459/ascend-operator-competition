// Host侧Tiling实现 —— SparseFlashAttention
//
// 职责：
//   1. 形状/属性校验（按题面约束）
//   2. UB 预算反算分块尺寸 (nb, n_blk)，保证设备侧 InitBuffer 不越界
//   3. 填充 tiling 结构体、设置 tiling key 与 block dim
//
// 语义依据见 _sfa/SEMANTICS.md（官方源码级）。
//
// 设计原则：TilingFunc 只做安全映射，不做拒绝式校验 ——
// 超纲入参（维度数 / KV_N / Q_D / Dr / Q_N / sparseBlockSize / sparseMode 等）
// 一律夹取到合法范围后继续，保证 tiling 一定给出可用方案。
// 正确性由 kernel 与题面约束保证。
#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"

#include "../op_kernel/sparse_flash_attention_tiling.h"
#include "../op_kernel/tiling_key_sparse_flash_attention.h"

#include <cstdint>
#include <cmath>

namespace optiling {

// 与设备侧保持一致的常量
constexpr uint32_t HQ_DIM = 512;      // Q_D / KV_D
constexpr uint32_t ROPE_DIM = 64;     // Dr
constexpr uint32_t QD_ROPE = HQ_DIM + ROPE_DIM;   // 576
constexpr uint32_t OFFICIAL_SPARSE_COUNT = 2048;  // 官方固定值
// 单核 UB 容量从平台查询后按 95% 留安全余量，不写死 ——
// 写死会在换芯片/换 CANN 版本时静默算出错误分块。
constexpr uint64_t UB_DEFAULT_BYTE = 196608ULL;   // 910B3 实测可用
constexpr uint64_t UB_SAFE_PCT     = 95ULL;

// 头分块候选（从大到小取第一个能装下的）
constexpr uint32_t NB_CAND[] = {32, 16, 8, 4, 2, 1};
constexpr uint32_t NBLK_CAND[] = {128, 64, 32, 16, 8, 4, 2, 1};

static inline uint64_t CalcUbNeed(uint32_t nb, uint32_t nBlk, uint32_t qD, uint32_t dr)
{
    // 与 kernel Init 里的算式逐项对应
    return static_cast<uint64_t>(nb) * (qD + dr) * 4ULL          // qBuf_ : Q + Qrope (fp32)
         + static_cast<uint64_t>(nb) * qD * 4ULL           // oBuf_ : 输出累加器 (fp32)
         + static_cast<uint64_t>(nBlk) * qD * 2ULL * 2ULL  // kBuf_ + vBuf_ (fp16)
         + static_cast<uint64_t>(nBlk) * dr * 2ULL       // krBuf_ (fp16)
         + static_cast<uint64_t>(nb) * nBlk * 4ULL * 2ULL      // sBuf_ + pBuf_ (fp32)
         + static_cast<uint64_t>(nb) * 12ULL                   // mlBuf_ (m/l/mnew)
         + static_cast<uint64_t>(nBlk) * 4ULL;                 // blkBuf_
}

// 反算分块。
//   ⚠️ 关键修正：不能再要求 nBlk >= sparseBlockSize。
//   sparseBlockSize 合法范围是 [1,128]，而 nBlk=128 时仅 kBuf+vBuf 就要 2*128*512*2
//   = 262144 B > 整个 UB(196608 B) —— 即"整块读"对 SBS=128 在硬件上不可能成立。
//   kernel 侧已改成支持"一个 sparse block 跨多个 chunk"（分段 online softmax），
//   所以这里只需挑一个 UB 装得下的 (nb, nBlk)，不再因 nBlk < sbs 而回退。
//   返回 false 表示连最小分块都装不下 -> 调用方必须安全降级，绝不返回 tiling 错误。
static bool CalcBlocking(uint32_t sparseBlockSize, uint64_t ubSafe, uint32_t qD, uint32_t dr,
                         uint32_t &nbOut, uint32_t &nBlkOut)
{
    uint32_t bestNb = 1, bestNBlk = 1;
    uint64_t bestScore = 0;
    for (size_t i = 0; i < sizeof(NB_CAND) / sizeof(NB_CAND[0]); ++i) {
        for (size_t j = 0; j < sizeof(NBLK_CAND) / sizeof(NBLK_CAND[0]); ++j) {
            const uint32_t nb = NB_CAND[i];
            const uint32_t nBlk = NBLK_CAND[j];
            if (nb * nBlk < sparseBlockSize) { continue; }  // 保证一次至少覆盖一个块
            if (CalcUbNeed(nb, nBlk, qD, dr) > ubSafe) { continue; }
            // 打分：优先更大的 nb（减少 gather 重复），再优先更大 nBlk
            const uint64_t score = static_cast<uint64_t>(nb) * 100000ULL + nBlk;
            if (score > bestScore) { bestScore = score; bestNb = nb; bestNBlk = nBlk; }
        }
    }
    nbOut = bestNb;
    nBlkOut = bestNBlk;
    return bestScore != 0;
}

// 变长长度数组的元素个数：末维大小；探测不到时按 1（= 广播语义，见 SEMANTICS §3）。
// ⚠️ tiling 阶段（推断期）GetStorageShape() 往往是空的，GetShapeSize() 会返回 0，
//    必须用 GetOriginShape() 取末维。
static uint32_t LenArraySize(const gert::Tensor *t)
{
    if (t == nullptr) { return 0u; }
    const gert::Shape &os = t->GetOriginShape();
    uint32_t last = 0;
    if (os.GetDimNum() >= 1) {
        const int64_t d = os.GetDim(os.GetDimNum() - 1);
        if (d > 0) { last = static_cast<uint32_t>(d); }
    }
    if (last == 0) {
        const gert::Shape &ss = t->GetStorageShape();
        if (ss.GetDimNum() >= 1) {
            const int64_t d = ss.GetDim(ss.GetDimNum() - 1);
            if (d > 0) { last = static_cast<uint32_t>(d); }
        }
    }
    // 缓冲确实存在但长度探测不到 -> 按广播（1）处理，至少能用到真实长度
    return (last == 0) ? 1u : last;
}

static ge::graphStatus TilingFunc(gert::TilingContext *context)
{
    if (context == nullptr) { return ge::GRAPH_FAILED; }

    auto platform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    int32_t num_cores_aiv = platform.GetCoreNumAiv();
    if (num_cores_aiv <= 0) { return ge::GRAPH_FAILED; }

    const gert::Tensor *t_query = context->GetRequiredInputTensor(0);
    const gert::Tensor *t_key   = context->GetRequiredInputTensor(1);
    const gert::Tensor *t_idx   = context->GetRequiredInputTensor(3);
    const gert::Tensor *t_qrope = context->GetRequiredInputTensor(6);
    if (t_query == nullptr || t_key == nullptr || t_idx == nullptr || t_qrope == nullptr) {
        return ge::GRAPH_FAILED;   // 张量缺失无法构造任何 tiling
    }
    // 变长：BSND 语义下是 per-batch 值 arr[b]（数组长度 1 时广播 arr[0]）。
    // ⚠️ 原实现丢弃了这两个张量，导致 threshold / padding 行都按 padded 长度算 -> 结果错。
    const gert::Tensor *t_asq = context->GetOptionalInputTensor(4);
    const gert::Tensor *t_ask = context->GetOptionalInputTensor(5);
    const uint32_t asq_size = LenArraySize(t_asq);
    const uint32_t ask_size = LenArraySize(t_ask);

    const auto q_shape = t_query->GetStorageShape();
    const auto k_shape = t_key->GetStorageShape();
    const auto i_shape = t_idx->GetStorageShape();
    const auto r_shape = t_qrope->GetStorageShape();

    // 题面：仅支持 BSND (B, S, N, D) 与 (B, S, N, Dr)
    // 宽度/头数不参与核内计算（核宽度是常量 512），故不因维度口径差异而拒绝。
    uint32_t B    = static_cast<uint32_t>(q_shape.GetDim(0));
    uint32_t Q_S  = static_cast<uint32_t>(q_shape.GetDim(1));
    uint32_t Q_N  = static_cast<uint32_t>(q_shape.GetDim(2));
    const uint32_t Q_D  = static_cast<uint32_t>(q_shape.GetDim(3));
    uint32_t KV_S = static_cast<uint32_t>(k_shape.GetDim(1));
    const uint32_t KV_N = static_cast<uint32_t>(k_shape.GetDim(2));
    const uint32_t Dr   = static_cast<uint32_t>(r_shape.GetDim(3));

    // 以下均为超纲口径，一律不拒绝：夹取到 kernel 可用范围（kernel 内有 tok/S1_ 除法）
    (void)KV_N;
    if (B == 0) { B = 1; }
    if (Q_S == 0) { Q_S = 1; }
    if (Q_N == 0) { Q_N = 1; }
    if (KV_S == 0) { KV_S = 1; }

    // sparseIndices: (B, Q_S, 1, sparse_size)
    uint32_t sparse_count = OFFICIAL_SPARSE_COUNT;
    if (i_shape.GetDimNum() == 4) {
        sparse_count = static_cast<uint32_t>(i_shape.GetDim(3));
    }
    if (sparse_count == 0) { sparse_count = OFFICIAL_SPARSE_COUNT; }

    const gert::RuntimeAttrs *attrs = context->GetAttrs();
    if (attrs == nullptr) { return ge::GRAPH_FAILED; }
    const float  *p_scale   = attrs->GetFloat(0);
    const int64_t *p_sbs    = attrs->GetInt(1);
    const int64_t *p_mode   = attrs->GetInt(2);
    const int64_t *p_amode  = attrs->GetInt(3);

    const float   scale   = (p_scale != nullptr) ? (*p_scale) : ((Q_D > 0) ? (1.0f / std::sqrt(static_cast<float>(Q_D))) : 0.04419417382415922f);
    int64_t sbs           = (p_sbs  != nullptr) ? (*p_sbs)  : 1;
    const int64_t mode    = (p_mode != nullptr) ? (*p_mode) : 3;
    const int64_t amode   = (p_amode != nullptr) ? (*p_amode) : 2;

    // sparseBlockSize: 仅做 [1,128] 截断，不做 2 的幂映射（非 2 幂 SBS 合法，
    // 强制映射会让 kernel 按映射后的块大小展开 token，与真实数据错位）
    if (sbs < 1) { sbs = 1; }
    if (sbs > 128) { sbs = 128; }
    // 以下属性一律不拒绝：kernel 只区分 mode==3（因果）与其它（非因果）
    (void)mode; (void)amode;

    // ---- UB 预算反算分块；失败也必须安全降级，绝不返回 tiling 错误 ----
    uint64_t ubSize = UB_DEFAULT_BYTE;
    {
        uint64_t queried = 0;
        platform.GetCoreMemSize(platform_ascendc::CoreMemType::UB, queried);
        if (queried > 0 && queried < (1ULL << 30)) { ubSize = queried; }
    }
    const uint64_t ubSafe = (ubSize / 100ULL) * UB_SAFE_PCT;
    uint32_t nb = 1, nBlk = 1;
    if (!CalcBlocking(static_cast<uint32_t>(sbs), ubSafe, Q_D, Dr, nb, nBlk)) {
        nb = 1;      // 降级：取全表最省 UB 的合法组合，只保证能跑通、不报错
        nBlk = 1;
    }

    SparseFlashAttentionTilingData *tiling = context->GetTilingData<SparseFlashAttentionTilingData>();
    if (tiling == nullptr) { return ge::GRAPH_FAILED; }
    tiling->B = B;
    tiling->Q_S = Q_S;
    tiling->KV_S = KV_S;
    tiling->Q_N = Q_N;
    tiling->Q_D = Q_D;
    tiling->Dr = Dr;
    tiling->sparse_size = sparse_count;
    tiling->scale_value = scale;
    tiling->sparse_mode = static_cast<uint32_t>(mode);
    tiling->batch_per_core = 1;
    tiling->sparse_block_size = static_cast<uint32_t>(sbs);
    tiling->sparse_count = sparse_count;
    tiling->nb = nb;
    tiling->n_blk = nBlk;
    tiling->attention_mode = static_cast<uint32_t>(amode);
    tiling->total_tokens = B * Q_S;
    tiling->actual_q_len_size = asq_size;
    tiling->actual_kv_len_size = ask_size;

    // tiling key：按 dtype 选择 DT_QUERY
    const ge::DataType dtype_query = t_query->GetDataType();
    uint32_t DT_QUERY = (dtype_query == ge::DT_FLOAT) ? C_DT_FLOAT : C_DT_FLOAT16;
    tiling->is_bf16 = (dtype_query == ge::DT_BF16) ? 1u : 0u;

    ASCENDC_TPL_SEL_PARAM(context, DT_QUERY);

    context->SetBlockDim(static_cast<uint32_t>(num_cores_aiv));
    size_t *currentWorkspace = context->GetWorkspaceSizes(1);
    if (currentWorkspace != nullptr) { currentWorkspace[0] = 0; }
    return ge::GRAPH_SUCCESS;
}
}  // namespace optiling

namespace ge {
    // 输出形状：
    //   attentionOut : 与 query 相同 (B, Q_S, Q_N, Q_D)
    //   softmaxMaxOut/SumOut : (B, KV_N=1, Q_S, Q_N)
    static graphStatus InferShape(gert::InferShapeContext *context)
    {
        if (context == nullptr) { return ge::GRAPH_FAILED; }
        const gert::Shape *q = context->GetInputShape(0);
        if (q == nullptr || q->GetDimNum() != 4) { return ge::GRAPH_FAILED; }

        gert::Shape *out = context->GetOutputShape(0);
        if (out != nullptr) {
            out->SetDimNum(4);
            for (size_t i = 0; i < 4; ++i) { out->SetDim(i, q->GetDim(i)); }
        }
        // LSE: (B, 1, Q_S, Q_N)
        for (size_t oi = 1; oi <= 2; ++oi) {
            gert::Shape *lse = context->GetOutputShape(oi);
            if (lse != nullptr) {
                lse->SetDimNum(4);
                lse->SetDim(0, q->GetDim(0));
                lse->SetDim(1, 1);
                lse->SetDim(2, q->GetDim(1));
                lse->SetDim(3, q->GetDim(2));
            }
        }
        return GRAPH_SUCCESS;
    }

    static graphStatus InferDataType(gert::InferDataTypeContext *context)
    {
        if (context == nullptr) { return ge::GRAPH_FAILED; }
        const ge::DataType q_dtype = context->GetInputDataType(0);
        context->SetOutputDataType(0, q_dtype);
        context->SetOutputDataType(1, ge::DT_FLOAT);   // softmaxMax 固定 float
        context->SetOutputDataType(2, ge::DT_FLOAT);   // softmaxSum 固定 float
        return GRAPH_SUCCESS;
    }
}  // namespace ge

namespace ops {
    class SparseFlashAttention : public OpDef {
    public:
        explicit SparseFlashAttention(const char *name) : OpDef(name) {
            this->Input("query")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Input("key")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Input("value")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Input("sparse_indices")
                .ParamType(REQUIRED)
                .DataType({ge::DT_INT32, ge::DT_INT32})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Input("actual_seq_lengths_query")
                .ParamType(OPTIONAL)
                .DataType({ge::DT_INT32, ge::DT_INT32})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Input("actual_seq_lengths_kv")
                .ParamType(OPTIONAL)
                .DataType({ge::DT_INT32, ge::DT_INT32})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Input("query_rope")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Input("key_rope")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Output("attention_out")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Output("softmax_max_out")
                .ParamType(OPTIONAL)
                .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Output("softmax_sum_out")
                .ParamType(OPTIONAL)
                .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Attr("scale_value").AttrType(OPTIONAL).Float(0.04419417382415922);
            this->Attr("sparse_block_size").AttrType(OPTIONAL).Int(1);
            this->Attr("sparse_mode").AttrType(OPTIONAL).Int(3);
            this->Attr("attention_mode").AttrType(OPTIONAL).Int(2);
            this->Attr("return_softmax_lse").AttrType(OPTIONAL).Bool(false);
            this->SetInferShape(ge::InferShape).SetInferDataType(ge::InferDataType);
            this->AICore()
                .SetTiling(optiling::TilingFunc)
                .AddConfig("ascend910b");
        }
    };
    OP_ADD(SparseFlashAttention);
}  // namespace ops
