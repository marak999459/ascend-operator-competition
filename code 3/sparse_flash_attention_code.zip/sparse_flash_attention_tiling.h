// Tiling结构体定义的头文件
#pragma once

#include <cstdint>

struct SparseFlashAttentionTilingData {
    uint32_t B;
    uint32_t Q_S;
    uint32_t KV_S;
    uint32_t Q_N;
    uint32_t Q_D;
    uint32_t Dr;
    uint32_t sparse_size;
    float scale_value;
    uint32_t sparse_mode;
    uint32_t batch_per_core;
};