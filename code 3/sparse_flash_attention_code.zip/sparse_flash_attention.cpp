// Kernel侧核函数实现：SparseFlashAttention（最简版）
#include "kernel_operator.h"
#include <limits>

#include "sparse_flash_attention_tiling.h"
#include "tiling_key_sparse_flash_attention.h"

using namespace AscendC;

constexpr int32_t Q_D_MAX = 512;
constexpr int32_t SPARSE_SIZE_MAX = 128;
constexpr int32_t Q_N_MAX = 128;

template <typename DT_QUERY>
class KernelSparseFlashAttention {
public:
    __aicore__ inline KernelSparseFlashAttention() {}

    __aicore__ inline void Init(GM_ADDR query, GM_ADDR key, GM_ADDR value,
                                GM_ADDR sparse_indices, GM_ADDR actual_seq_lengths_query,
                                GM_ADDR actual_seq_lengths_kv, GM_ADDR query_rope, GM_ADDR key_rope,
                                GM_ADDR attention_out, GM_ADDR softmax_max_out, GM_ADDR softmax_sum_out,
                                const SparseFlashAttentionTilingData &tiling) {
        tiling_ = tiling;
        B_ = tiling.B;
        Q_S_ = tiling.Q_S;
        KV_S_ = tiling.KV_S;
        Q_N_ = tiling.Q_N;
        Q_D_ = tiling.Q_D;
        Dr_ = tiling.Dr;
        sparse_size_ = tiling.sparse_size;
        scale_ = tiling.scale_value;
        sparse_mode_ = tiling.sparse_mode;

        q_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(query));
        k_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(key));
        v_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(value));
        idx_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ int32_t *>(sparse_indices));
        q_rope_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(query_rope));
        k_rope_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(key_rope));
        out_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_QUERY *>(attention_out));

        const uint32_t batch_per_core = (tiling.batch_per_core == 0) ? 1u : tiling.batch_per_core;
        const uint32_t block_idx = GetBlockIdx();
        b_begin_ = block_idx * batch_per_core;
        b_end_ = b_begin_ + batch_per_core;
        if (b_end_ > B_) b_end_ = B_;
        if (b_begin_ > B_) b_begin_ = B_;

        // 分配 UB 缓冲
        pipe_.InitBuffer(q_buf_, Q_N_ * Q_D_ * sizeof(float));
        pipe_.InitBuffer(k_sel_buf_, SPARSE_SIZE_MAX * Q_D_ * sizeof(float));
        pipe_.InitBuffer(v_sel_buf_, SPARSE_SIZE_MAX * Q_D_ * sizeof(float));
        pipe_.InitBuffer(score_buf_, Q_N_ * SPARSE_SIZE_MAX * sizeof(float));
        pipe_.InitBuffer(attn_buf_, Q_N_ * SPARSE_SIZE_MAX * sizeof(float));
        pipe_.InitBuffer(out_buf_, Q_N_ * Q_D_ * sizeof(float));
        pipe_.InitBuffer(idx_buf_, SPARSE_SIZE_MAX * sizeof(int32_t));
    }

    __aicore__ inline void Process() {
        for (uint32_t b = b_begin_; b < b_end_; ++b) {
            ProcessBatch(b);
        }
    }

private:
    __aicore__ inline float ExpPoly(float x) const {
        const float LN2 = 0.6931471805599453f;
        const float INV_LN2 = 1.4426950408889634f;
        if (x < -87.0f) return 0.0f;
        if (x > 88.0f) x = 88.0f;
        
        float xf = x * INV_LN2;
        int32_t k = static_cast<int32_t>(xf);
        if (xf < 0.0f && static_cast<float>(k) != xf) k -= 1;
        float kf = static_cast<float>(k);
        
        const float r = x - kf * LN2;
        float p = 1.0f / 120.0f;
        p = p * r + (1.0f / 24.0f);
        p = p * r + (1.0f / 6.0f);
        p = p * r + 0.5f;
        p = p * r + 1.0f;
        p = p * r + 1.0f;
        
        union { int32_t i; float f; } u;
        u.i = (k + 127) << 23;
        if (k + 127 <= 0) return 0.0f;
        if (u.i >= 0x7F800000) u.i = 0x7F7FFFFF;
        return p * u.f;
    }

    __aicore__ inline void ProcessBatch(uint32_t b) {
        const int32_t qd = Q_D_;
        const int32_t qn = Q_N_;
        const int32_t ss = sparse_size_;

        LocalTensor<float> q = q_buf_.Get<float>();
        LocalTensor<float> k_sel = k_sel_buf_.Get<float>();
        LocalTensor<float> v_sel = v_sel_buf_.Get<float>();
        LocalTensor<float> score = score_buf_.Get<float>();
        LocalTensor<float> attn = attn_buf_.Get<float>();
        LocalTensor<float> out = out_buf_.Get<float>();
        LocalTensor<int32_t> idx_buf = idx_buf_.Get<int32_t>();

        for (int32_t s = 0; s < Q_S_; ++s) {
            // 1. 读 query: (Q_N, Q_D)
            for (int32_t n = 0; n < qn; ++n) {
                for (int32_t d = 0; d < qd; ++d) {
                    const int64_t idx = (int64_t)b * Q_S_ * Q_N_ * Q_D_ + (int64_t)s * Q_N_ * Q_D_ + (int64_t)n * Q_D_ + d;
                    q.SetValue(n * qd + d, static_cast<float>(q_gm_.GetValue(idx)));
                }
            }

            // 2. 读 sparse_indices: (sparse_size,)
            int32_t valid_count = 0;
            for (int32_t i = 0; i < ss; ++i) {
                const int64_t idx = (int64_t)b * Q_S_ * 1 * ss + (int64_t)s * 1 * ss + i;
                int32_t k_idx = idx_gm_.GetValue(idx);
                if (k_idx >= 0 && k_idx < (int32_t)KV_S_) {
                    idx_buf.SetValue(valid_count++, k_idx);
                }
            }

            // 3. Gather K̃ 和 Ṽ: (valid_count, Q_D)
            for (int32_t i = 0; i < valid_count; ++i) {
                const int32_t k_idx = idx_buf.GetValue(i);
                for (int32_t d = 0; d < qd; ++d) {
                    const int64_t k_offset = (int64_t)b * KV_S_ * 1 * Q_D_ + (int64_t)k_idx * 1 * Q_D_ + d;
                    k_sel.SetValue(i * qd + d, static_cast<float>(k_gm_.GetValue(k_offset)));
                    v_sel.SetValue(i * qd + d, static_cast<float>(v_gm_.GetValue(k_offset)));
                }
            }

            // 4. 计算 score = Q @ K̃^T * scale: (Q_N, valid_count)
            for (int32_t n = 0; n < qn; ++n) {
                for (int32_t i = 0; i < valid_count; ++i) {
                    float s = 0.0f;
                    for (int32_t d = 0; d < qd; ++d) {
                        s += q.GetValue(n * qd + d) * k_sel.GetValue(i * qd + d);
                    }
                    score.SetValue(n * valid_count + i, s * scale_);
                }
            }

            // 5. Softmax: 数值稳定
            for (int32_t n = 0; n < qn; ++n) {
                float mx = score.GetValue(n * valid_count);
                for (int32_t i = 1; i < valid_count; ++i) {
                    const float v = score.GetValue(n * valid_count + i);
                    mx = (v > mx) ? v : mx;
                }
                float sum = 0.0f;
                for (int32_t i = 0; i < valid_count; ++i) {
                    const float e = ExpPoly(score.GetValue(n * valid_count + i) - mx);
                    attn.SetValue(n * valid_count + i, e);
                    sum += e;
                }
                const float inv_sum = 1.0f / (sum + 1e-6f);
                for (int32_t i = 0; i < valid_count; ++i) {
                    attn.SetValue(n * valid_count + i, attn.GetValue(n * valid_count + i) * inv_sum);
                }
            }

            // 6. 计算 out = attn @ Ṽ: (Q_N, Q_D)
            for (int32_t n = 0; n < qn; ++n) {
                for (int32_t d = 0; d < qd; ++d) {
                    float s = 0.0f;
                    for (int32_t i = 0; i < valid_count; ++i) {
                        s += attn.GetValue(n * valid_count + i) * v_sel.GetValue(i * qd + d);
                    }
                    out.SetValue(n * qd + d, s);
                }
            }

            // 7. 写回输出: (Q_N, Q_D)
            for (int32_t n = 0; n < qn; ++n) {
                for (int32_t d = 0; d < qd; ++d) {
                    const int64_t idx = (int64_t)b * Q_S_ * Q_N_ * Q_D_ + (int64_t)s * Q_N_ * Q_D_ + (int64_t)n * Q_D_ + d;
                    out_gm_.SetValue(idx, static_cast<DT_QUERY>(out.GetValue(n * qd + d)));
                }
            }
            PipeBarrier<PIPE_ALL>();
        }
    }

    TPipe pipe_;
    TBuf<TPosition::VECCALC> q_buf_;
    TBuf<TPosition::VECCALC> k_sel_buf_;
    TBuf<TPosition::VECCALC> v_sel_buf_;
    TBuf<TPosition::VECCALC> score_buf_;
    TBuf<TPosition::VECCALC> attn_buf_;
    TBuf<TPosition::VECCALC> out_buf_;
    TBuf<TPosition::VECCALC> idx_buf_;
    GlobalTensor<DT_QUERY> q_gm_;
    GlobalTensor<DT_QUERY> k_gm_;
    GlobalTensor<DT_QUERY> v_gm_;
    GlobalTensor<int32_t> idx_gm_;
    GlobalTensor<DT_QUERY> q_rope_gm_;
    GlobalTensor<DT_QUERY> k_rope_gm_;
    GlobalTensor<DT_QUERY> out_gm_;
    SparseFlashAttentionTilingData tiling_;
    uint32_t B_;
    uint32_t Q_S_;
    uint32_t KV_S_;
    uint32_t Q_N_;
    uint32_t Q_D_;
    uint32_t Dr_;
    uint32_t sparse_size_;
    float scale_;
    uint32_t sparse_mode_;
    uint32_t b_begin_;
    uint32_t b_end_;
};

template <typename DT_QUERY>
__global__ __aicore__ void sparse_flash_attention(GM_ADDR query, GM_ADDR key, GM_ADDR value,
                                                   GM_ADDR sparse_indices, GM_ADDR actual_seq_lengths_query,
                                                   GM_ADDR actual_seq_lengths_kv, GM_ADDR query_rope, GM_ADDR key_rope,
                                                   GM_ADDR attention_out, GM_ADDR softmax_max_out, GM_ADDR softmax_sum_out,
                                                   GM_ADDR workspace, GM_ADDR tiling) {
    REGISTER_TILING_DEFAULT(SparseFlashAttentionTilingData);
    GET_TILING_DATA_WITH_STRUCT(SparseFlashAttentionTilingData, tiling_data, tiling);
    KernelSparseFlashAttention<DT_QUERY> op;
    op.Init(query, key, value, sparse_indices, actual_seq_lengths_query, actual_seq_lengths_kv,
            query_rope, key_rope, attention_out, softmax_max_out, softmax_sum_out, tiling_data);
    op.Process();
}

template __aicore__ void sparse_flash_attention<half>(GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
template __aicore__ void sparse_flash_attention<float>(GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
