// Host侧Tiling实现
#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"

#include <algorithm>
#include <cstdint>

#include "../op_kernel/mhc_expand_tiling.h"
#include "../op_kernel/tiling_key_mhc_expand.h"

namespace {
// 切分模式枚举（与 TilingData.splitMode 一致）
constexpr uint32_t SPLIT_ROW = 0;          // 按 token 行切核（首选）
constexpr uint32_t SPLIT_ROW_STREAM = 1;   // 前向：把 (s, k) 展开为 S*m 个写任务
constexpr uint32_t SPLIT_ELEMENT = 2;      // 极端小 shape：按 (s, jt) 扁平切
}  // namespace

namespace optiling {
    static ge::graphStatus TilingFunc(gert::TilingContext *context) {
        // ---- 平台信息 ----
        auto platform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
        int32_t num_cores_aiv = platform.GetCoreNumAiv();
        uint64_t ub_size = 0;
        platform.GetCoreMemSize(platform_ascendc::CoreMemType::UB, ub_size);
        if (ub_size == 0) {
            ub_size = 192 * 1024;   // 防御：默认 910B UB 约 192KB
        }

        // ---- 输入信息 ----
        const gert::Tensor *tensor_x = context->GetRequiredInputTensor(0);
        ge::DataType dtype_x = tensor_x->GetDataType();
        int dtype_size_x = ge::GetSizeByDataType(dtype_x);
        const gert::StorageShape *in_storage_shape = context->GetInputShape(0);
        const gert::Shape &in_shape = in_storage_shape->GetStorageShape();
        size_t in_rank = in_shape.GetDimNum();

        // ---- 算子属性 ----
        const gert::RuntimeAttrs *attrs = context->GetAttrs();
        const int64_t *attr_mhc_mult = attrs->GetInt(0);
        const bool *attr_backward = attrs->GetBool(1);
        int64_t m = (attr_mhc_mult != nullptr) ? *attr_mhc_mult : 2;
        bool backward = (attr_backward != nullptr) ? *attr_backward : false;

        if (m < 1) {
            return ge::GRAPH_FAILED;   // 扩展倍数必须 >= 1
        }

        // ---- 语义消歧：按 backward + rank 解析 S / D ----
        uint32_t S = 0, D = 0;
        if (!backward) {
            if (in_rank != 2) return ge::GRAPH_FAILED;   // 前向期望 [S, D]
            S = static_cast<uint32_t>(in_shape.GetDim(0));
            D = static_cast<uint32_t>(in_shape.GetDim(1));
        } else {
            if (in_rank != 3) return ge::GRAPH_FAILED;   // 反向期望 [S, m, D]
            if (static_cast<int64_t>(in_shape.GetDim(1)) != m) return ge::GRAPH_FAILED;
            S = static_cast<uint32_t>(in_shape.GetDim(0));
            D = static_cast<uint32_t>(in_shape.GetDim(2));
        }
        if (S == 0 || D == 0) return ge::GRAPH_FAILED;

        // ---- 配置 tiling key（dtype 模板域：fp16 / bf16；backward 布尔模板域） ----
        uint32_t DT_X = 0;
        if (dtype_x == ge::DT_FLOAT16) {
            DT_X = C_DT_FLOAT16;
        } else if (dtype_x == ge::DT_BF16) {
            DT_X = C_DT_BF16;
        } else {
            return ge::GRAPH_FAILED;
        }
        uint32_t BACKWARD = backward ? 1u : 0u;
        ASCENDC_TPL_SEL_PARAM(context, DT_X, BACKWARD);

        // ---- 填充 TilingData ----
        MhcExpandTilingData *tiling = context->GetTilingData<MhcExpandTilingData>();
        tiling->S = S;
        tiling->D = D;
        tiling->m = static_cast<uint32_t>(m);
        tiling->backward = backward ? 1u : 0u;

        // D 方向大 tile：32B 对齐（fp16/bf16 = 16 元素），典型 512~2048；
        // 核内同时只持有 1 份 D（前向读 1 次写 m 次、反向逐副本读），
        // 故只需 D*elem_size 放得进 UB 的 1/4 即可整行一次 DMA。
        const uint64_t elem_size = static_cast<uint64_t>(dtype_size_x);
        const uint64_t ub_budget = ub_size / 4;
        uint32_t d_tile_len = 0;
        if (static_cast<uint64_t>(D) * elem_size <= ub_budget) {
            d_tile_len = D;                              // 整行模式：dTileNum = 1
        } else {
            uint64_t t = std::min<uint64_t>(2048, D);
            uint64_t max_t = ub_budget / elem_size;
            t = std::min(t, max_t);
            if (t > 16) t = (t / 16) * 16;               // 32B 对齐
            if (t < 16) t = 16;
            if (t > D) t = D;
            if (t < 1) t = 1;                            // 极端兜底
            d_tile_len = static_cast<uint32_t>(t);
        }
        tiling->dTileLen = d_tile_len;
        tiling->dTileNum = (D + d_tile_len - 1) / d_tile_len;
        tiling->dTailLen = D - (tiling->dTileNum - 1) * d_tile_len;

        // ---- 切分决策（"切分最优"得分点，DESIGN.md §3.5） ----
        uint32_t num_aiv = static_cast<uint32_t>(num_cores_aiv);
        if (num_aiv == 0) num_aiv = 1;
        uint64_t total_tasks = 0;
        uint32_t split_mode = SPLIT_ROW;
        uint32_t block_dim = num_aiv;

        if (S >= num_aiv) {
            // 行数足够 → 按 token 行切核（首选，每核负责连续若干整行）
            split_mode = SPLIT_ROW;
            total_tasks = S;
        } else if (!backward) {
            uint64_t stream_tasks = static_cast<uint64_t>(S) * m;
            if (stream_tasks >= num_aiv) {
                // 前向 S 小：把 (s, k) 展开为 S*m 个写任务，充分用核
                split_mode = SPLIT_ROW_STREAM;
                total_tasks = stream_tasks;
            } else {
                // 前向极端小 shape：按 (s, k, jt) 扁平切
                split_mode = SPLIT_ELEMENT;
                total_tasks = static_cast<uint64_t>(S) * m * tiling->dTileNum;
            }
        } else {
            // 反向小 S：按 (s, jt) 切（每个输出元素由唯一核负责，免跨核归约，无需 workspace）
            split_mode = SPLIT_ELEMENT;
            total_tasks = static_cast<uint64_t>(S) * tiling->dTileNum;
        }

        if (total_tasks < num_aiv) block_dim = static_cast<uint32_t>(total_tasks);
        if (block_dim == 0) block_dim = 1;

        // ---- 小档少开核（真机实测 2026-09-20，见 code1.md §14）----
        // 每多启动一个 block 要多付一次派发 + 每核固定序言（实测约 45ns/块），
        // 所以"每核分到的字节"低于拐点时开核反而更慢：
        //   fwd-fp16-small(96KB) blk=40 -> 4.1us，blk=16 -> 3.2us，blk=12 -> 3.0us，blk=2 -> 7.0us
        //   bwd-fp16-small(96KB) blk=40 -> 4.6us，blk=16 -> 3.4us，blk=12 -> 4.0us，blk=2 -> 11.8us
        // 前向 IO = S*D + S*m*D、反向同样 = (1+m)*S*D（谁当输入不影响总量），故一条公式覆盖两向。
        // 6KB/核 = 96KB/16 恰好落在上面两列的实测最优；medium(42MB)/large(8.4GB) 远不到拐点，
        // 仍按 num_aiv 满开核。
        const uint64_t io_bytes = static_cast<uint64_t>(m + 1) * static_cast<uint64_t>(S) *
                                  static_cast<uint64_t>(D) * elem_size;
        const uint64_t min_io_per_core = 6144;   // 6KB：低于此每核工作量再开核不划算
        uint64_t core_cap = io_bytes / min_io_per_core;
        if (core_cap < 1) core_cap = 1;
        if (core_cap < block_dim) block_dim = static_cast<uint32_t>(core_cap);


        tiling->splitMode = split_mode;
        tiling->blockDim = block_dim;
        tiling->rowsPerCore = static_cast<uint32_t>((total_tasks + block_dim - 1) / block_dim);
        // 最后一个核的任务数（uint64 计算避免溢出）
        uint64_t tail = total_tasks - static_cast<uint64_t>(tiling->rowsPerCore) * (block_dim - 1);
        tiling->tailRows = static_cast<uint32_t>(tail);

        // ---- 启动核数与 workspace ----
        context->SetBlockDim(block_dim);
        size_t *current_workspace = context->GetWorkspaceSizes(1);
        current_workspace[0] = 0;   // 本实现不需要 workspace
        return ge::GRAPH_SUCCESS;
    }
}  // namespace optiling

namespace ge {
    static graphStatus InferShape(gert::InferShapeContext *context) {
        const gert::Shape *in_shape = context->GetInputShape(0);
        const gert::RuntimeAttrs *attrs = context->GetAttrs();
        const int64_t *attr_mhc_mult = attrs->GetInt(0);
        const bool *attr_backward = attrs->GetBool(1);
        int64_t m = (attr_mhc_mult != nullptr) ? *attr_mhc_mult : 2;
        bool backward = (attr_backward != nullptr) ? *attr_backward : false;

        size_t in_rank = in_shape->GetDimNum();
        gert::Shape *out_shape = context->GetOutputShape(0);
        if (!backward) {
            // 前向： [S, D] -> [S, m, D]
            if (in_rank != 2 || m < 1) return GRAPH_FAILED;
            out_shape->SetDimNum(3);
            out_shape->SetDim(0, in_shape->GetDim(0));
            out_shape->SetDim(1, m);
            out_shape->SetDim(2, in_shape->GetDim(1));
        } else {
            // 反向： [S, m, D] -> [S, D]
            if (in_rank != 3 || m < 1) return GRAPH_FAILED;
            if (in_shape->GetDim(1) != m) return GRAPH_FAILED;
            out_shape->SetDimNum(2);
            out_shape->SetDim(0, in_shape->GetDim(0));
            out_shape->SetDim(1, in_shape->GetDim(2));
        }
        return GRAPH_SUCCESS;
    }

    static graphStatus InferDataType(gert::InferDataTypeContext *context) {
        ge::DataType in_dtype = context->GetInputDataType(0);   // 返回值类型是 ge::DataType（值）
        context->SetOutputDataType(0, in_dtype);                // 参数类型也是 ge::DataType（值）
        return GRAPH_SUCCESS;
    }
}  // namespace ge

namespace ops {
    class MhcExpand : public OpDef {
    public:
        explicit MhcExpand(const char *name) : OpDef(name) {
            this->Input("x")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_BF16})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Output("o")
                .ParamType(REQUIRED)
                .DataType({ge::DT_FLOAT16, ge::DT_BF16})
                .Format({ge::FORMAT_ND, ge::FORMAT_ND});
            this->Attr("mhc_mult").AttrType(OPTIONAL).Int(2);
            this->Attr("backward").AttrType(OPTIONAL).Bool(false);
            this->SetInferShape(ge::InferShape).SetInferDataType(ge::InferDataType);
            this->AICore()
                .SetTiling(optiling::TilingFunc)
                .AddConfig("ascend910b");
        }
    };
    OP_ADD(MhcExpand);
}  // namespace ops
