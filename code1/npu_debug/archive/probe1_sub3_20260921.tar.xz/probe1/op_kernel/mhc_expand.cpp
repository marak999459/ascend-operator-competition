// Kernel侧核函数实现：mHC-expand（前向复制广播 / 反向求和归约）
#include "kernel_operator.h"
#include "mhc_expand_tiling.h"
#include "tiling_key_mhc_expand.h"

using namespace AscendC;

template <typename DT_X, bool BACKWARD>
class KernelMhcExpand {
public:
    __aicore__ inline KernelMhcExpand() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR o, GM_ADDR workspace, const MhcExpandTilingData &tiling) {
        tiling_ = tiling;
        elem_size_ = sizeof(DT_X);
        const uint32_t s = tiling_.S;
        const uint32_t d = tiling_.D;
        const uint32_t m = tiling_.m;

        if constexpr (BACKWARD) {
            // 反向：x = o_grad [S, m, D]；o = x_grad [S, D]
            x_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_X *>(x),
                                  static_cast<int64_t>(s) * m * d);
            o_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_X *>(o),
                                  static_cast<int64_t>(s) * d);
        } else {
            // 前向：x = [S, D]；o = [S, m, D]
            x_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_X *>(x),
                                  static_cast<int64_t>(s) * d);
            o_gm_.SetGlobalBuffer(reinterpret_cast<__gm__ DT_X *>(o),
                                  static_cast<int64_t>(s) * m * d * 8 + 262144);  // [PROBE]
        }

        // 按 host 的 splitMode 拆核，小 shape 时把 m 维/元素维也铺到多核
        uint32_t core_num = tiling_.blockDim;
        if (core_num == 0) core_num = 1;
        uint32_t tpc = tiling_.rowsPerCore;
        if (tpc == 0) tpc = 1;
        uint32_t block_idx = GetBlockIdx();
        task_begin_ = block_idx * tpc;
        task_end_ = task_begin_ + tpc;
        // total_tasks 由 host 算好：ROW=S, STREAM=S*m, ELEMENT=S*m*dTileNum(前向)/S*dTileNum(反向)
        uint32_t total_tasks;
        if constexpr (BACKWARD) {
            total_tasks = (tiling_.splitMode == 2) ? s * tiling_.dTileNum : s;
        } else {
            if (tiling_.splitMode == 1) total_tasks = s * m;
            else if (tiling_.splitMode == 2) total_tasks = s * m * tiling_.dTileNum;
            else total_tasks = s;
        }
        if (task_end_ > total_tasks) task_end_ = total_tasks;

        // UB 缓冲（双缓冲）
        pipe_.InitBuffer(in_que_, 2, tiling_.dTileLen * elem_size_);
        pipe_.InitBuffer(out_que_, 2, tiling_.dTileLen * elem_size_);
        pipe_.InitBuffer(acc_buf_, tiling_.dTileLen * sizeof(float));
        pipe_.InitBuffer(tmp_buf_, tiling_.dTileLen * sizeof(float));
    }

    __aicore__ inline void Process() {
        if (task_begin_ >= task_end_) return;
        const uint32_t d_tile_num = tiling_.dTileNum;
        const uint32_t s = tiling_.S;
        const uint32_t m = tiling_.m;
        const uint32_t smode = tiling_.splitMode;

        for (uint32_t t = task_begin_; t < task_end_; ++t) {
            if constexpr (BACKWARD) {
                // 反向：ROW -> task=s; ELEMENT -> task=s*dTileNum+jt
                uint32_t s_idx, jt;
                if (smode == 2) { s_idx = t / d_tile_num; jt = t % d_tile_num; }
                else            { s_idx = t; jt = d_tile_num; } // jt=d_tile_num 表示遍历全部
                if (jt == d_tile_num) {
                    for (uint32_t j = 0; j < d_tile_num; ++j) {
                        const uint32_t cur_h = (j == d_tile_num - 1) ? tiling_.dTailLen : tiling_.dTileLen;
                        BackwardOneBlock(s_idx, j, cur_h);
                    }
                } else {
                    const uint32_t cur_h = (jt == d_tile_num - 1) ? tiling_.dTailLen : tiling_.dTileLen;
                    BackwardOneBlock(s_idx, jt, cur_h);
                }
            } else {
                // 前向：ROW -> task=s(全k); STREAM -> task=s*m+k(单k全jt); ELEMENT -> task=s*m*dTileNum+k*dTileNum+jt
                uint32_t s_idx, k, jt;
                if (smode == 0) { s_idx = t; k = m; jt = d_tile_num; } // k=m 表示全k
                else if (smode == 1) { s_idx = t / m; k = t % m; jt = d_tile_num; }
                else { uint32_t stride = m * d_tile_num; s_idx = t / stride; uint32_t r = t % stride; k = r / d_tile_num; jt = r % d_tile_num; }
                if (jt == d_tile_num) {
                    for (uint32_t j = 0; j < d_tile_num; ++j) {
                        const uint32_t cur_h = (j == d_tile_num - 1) ? tiling_.dTailLen : tiling_.dTileLen;
                        ForwardOneBlock(s_idx, j, cur_h, k);
                    }
                } else {
                    const uint32_t cur_h = (jt == d_tile_num - 1) ? tiling_.dTailLen : tiling_.dTileLen;
                    ForwardOneBlock(s_idx, jt, cur_h, k);
                }
            }
        }
    }

private:
    // 前向单块：读 x[i, jt] 一次，写 k_begin..k_end-1 个副本
    // k=m 表示全 k（ROW 模式 UB 复用），k<m 表示只写第 k 个（STREAM/ELEMENT 模式拆核）
    __aicore__ inline void ForwardOneBlock(uint32_t i, uint32_t jt, uint32_t cur_h, uint32_t k_limit) {
        const int64_t src_off = static_cast<int64_t>(i) * tiling_.D + jt * tiling_.dTileLen;
        DataCopyExtParams cp{1, static_cast<uint32_t>(cur_h * static_cast<int32_t>(sizeof(DT_X))), 0, 0, 0};
        DataCopyPadExtParams<DT_X> pp{false, 0, 0, static_cast<DT_X>(0)};

        auto in_buf = in_que_.AllocTensor<DT_X>();
        DataCopyPad(in_buf, x_gm_[src_off], cp, pp);
        in_que_.EnQue(in_buf);
        auto x_local = in_que_.DeQue<DT_X>();
        // 前向是纯搬运、中间没有 VEC 指令，TQue<VECIN> 的序只挂在 VEC 消费上，所以 MTE2
        // 落地与上一次 MTE1 读完这两道序得自己补；本路径无 VEC 动作，ALL 与单条 barrier 等价
        PipeBarrier<PIPE_ALL>();

        const uint32_t k_begin = (k_limit == tiling_.m) ? 0 : k_limit;
        const uint32_t k_end   = (k_limit == tiling_.m) ? tiling_.m : k_limit + 1;
// [PROBE P1] 单核受控裁定 arch22 上 DataCopyExtParams 的字段口径（code1.md §14.5 疑案）
// 替换 op_kernel/mhc_expand.cpp 里 ForwardOneBlock 的逐副本 for k 循环。
// 口径假设只有三种：dst 侧字段 = 块间隔(字节) / 块首距(字节) / 块首距(32B 块)。
// 让 m 取值决定填进去的数字，使得**恰好一种**解释会把 m 个副本写到正确位置：
//   m=2 -> 字段 0        ：只有"gap/字节"成立时 stride=rb（正确）；"stride=字节"解释成 0 ⇒ 第二副本没写
//   m=3 -> 字段 rb(字节) ：只有"stride/字节"成立时正确；"gap"解释 ⇒ 每副本间隔 2rb（越界进下一行）
//   m=4 -> 字段 rb/32    ：只有"stride/32B 块"成立时正确；"字节"解释 ⇒ 16 字节互相覆盖
// 三者互斥 ⇒ 只有一条会 PASS，PASS 的那条直接给出单位。m=8 走原逐副本循环 = 正对照。
        const uint32_t mm = tiling_.m;
        const uint32_t rb = cur_h * elem_size_;
        const bool one_shot = (tiling_.dTileNum == 1) && (k_limit == mm) && k_begin == 0 &&
                              (mm == 2 || mm == 3 || mm == 4);
        if (one_shot) {
            const int64_t dst0 = static_cast<int64_t>(i) * mm * tiling_.D + jt * tiling_.dTileLen;
            const uint32_t ds = (mm == 2) ? 0u : (mm == 3) ? rb : (rb / 32u);
            DataCopyExtParams pb{static_cast<uint16_t>(mm), rb, 0u, ds, 0u};
            DataCopyPad(o_gm_[dst0], x_local, pb);
        } else {
            for (uint32_t k = k_begin; k < k_end; ++k) {
                const int64_t dst_off = static_cast<int64_t>(i) * tiling_.m * tiling_.D +
                                        static_cast<int64_t>(k) * tiling_.D + jt * tiling_.dTileLen;
                DataCopyPad(o_gm_[dst_off], x_local, cp);
            }
        }
        in_que_.FreeTensor(x_local);
    }

    // 反向单块：逐 m 读 o_grad[i, k, jt] -> Cast 到 float 累加 -> Cast 回原 dtype 写 x_grad[i, jt]
    // 双缓冲流水线：DMA 读 k+1 与 VEC 算 k 并行，隐藏 DMA 延迟
    __aicore__ inline void BackwardOneBlock(uint32_t i, uint32_t jt, uint32_t cur_h) {
        const uint32_t m = tiling_.m;
        const int64_t base = static_cast<int64_t>(i) * m * tiling_.D + jt * tiling_.dTileLen;
        DataCopyExtParams cp{1, static_cast<uint32_t>(cur_h * static_cast<int32_t>(sizeof(DT_X))), 0, 0, 0};
        DataCopyPadExtParams<DT_X> pp{false, 0, 0, static_cast<DT_X>(0)};

        auto acc = acc_buf_.Get<float>();
        Duplicate(acc, 0.0f, cur_h);

        // 预取第 0 个副本
        auto next_dma_buf = in_que_.AllocTensor<DT_X>();
        DataCopyPad(next_dma_buf, x_gm_[base], cp, pp);
        in_que_.EnQue(next_dma_buf);

        for (uint32_t k = 0; k < m; ++k) {
            auto cur_dma_buf = next_dma_buf;
            auto compute_buf = in_que_.DeQue<DT_X>();

            // 启动下一个副本的 DMA（与当前 VEC 计算并行）
            if (k < m - 1) {
                next_dma_buf = in_que_.AllocTensor<DT_X>();
                DataCopyPad(next_dma_buf,
                            x_gm_[base + static_cast<int64_t>(k + 1) * tiling_.D],
                            cp, pp);
                in_que_.EnQue(next_dma_buf);
            }

            auto tmp = tmp_buf_.Get<float>();
            Cast(tmp, compute_buf, RoundMode::CAST_NONE, cur_h);
            Add(acc, acc, tmp, cur_h);
            in_que_.FreeTensor(compute_buf);
        }

        auto out_buf = out_que_.AllocTensor<DT_X>();
        Cast(out_buf, acc, RoundMode::CAST_RINT, cur_h);
        out_que_.EnQue(out_buf);
        auto o_local = out_que_.DeQue<DT_X>();
        DataCopyPad(o_gm_[static_cast<int64_t>(i) * tiling_.D + jt * tiling_.dTileLen], o_local, cp);
        out_que_.FreeTensor(o_local);
    }

    TPipe pipe_;
    TQue<QuePosition::VECIN, 2> in_que_;
    TQue<QuePosition::VECOUT, 2> out_que_;
    TBuf<TPosition::VECCALC> acc_buf_;
    TBuf<TPosition::VECCALC> tmp_buf_;
    GlobalTensor<DT_X> x_gm_;
    GlobalTensor<DT_X> o_gm_;
    MhcExpandTilingData tiling_;
    uint32_t elem_size_;
    uint32_t task_begin_;
    uint32_t task_end_;
};

template <typename DT_X, bool BACKWARD>
__global__ __aicore__ void mhc_expand(GM_ADDR x, GM_ADDR o, GM_ADDR workspace, GM_ADDR tiling) {
    REGISTER_TILING_DEFAULT(MhcExpandTilingData);
    GET_TILING_DATA_WITH_STRUCT(MhcExpandTilingData, tiling_data, tiling);
    KernelMhcExpand<DT_X, BACKWARD> op;
    op.Init(x, o, workspace, tiling_data);
    op.Process();
}

// 显式实例化模板（由 TilingKey 选择）
template __aicore__ void mhc_expand<half, false>(GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
template __aicore__ void mhc_expand<half, true>(GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
template __aicore__ void mhc_expand<bfloat16_t, false>(GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
template __aicore__ void mhc_expand<bfloat16_t, true>(GM_ADDR, GM_ADDR, GM_ADDR, GM_ADDR);
